import * as ActionType from '../ActionType'

const initialState = {
    isLoading: false,
    medicine: [],
    error: null
}
export const medicineReducer = (state = initialState, action) => {
    console.log(state)
    switch (action.type) {
        case ActionType.MEDICINE_GET: {
            return {
                ...state,
                medicine: action.payload
            }
        }
        default:{
            return state
        }
    }
}
import *  as ActionType from '../ActionType'

export const addMedicin = () => (dispatch) => {
    try {
        fetch('http://localhost:3000/posts')
            .then(response => response.text())
            .then((data) => console.log(data))
    } catch (error) {

    }
}